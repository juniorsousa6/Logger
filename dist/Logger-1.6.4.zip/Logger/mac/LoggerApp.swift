// Logger.app — janela nativa do Mac para o Logger.
// Sobe o motor em Python (app.py) em segundo plano, mostra a interface num WKWebView
// e cuida de: escolher pastas (painel nativo), não fechar no meio de uma cópia,
// atualização automática e recompilar sozinho quando o macOS muda de versão.
// Compilado no próprio Mac pelo instalador (swiftc das Ferramentas de Linha de Comando).

import Cocoa
import CryptoKit
import LocalAuthentication
import Security
import WebKit

let info = Bundle.main.infoDictionary ?? [:]
let APP_VERSION = info["CFBundleShortVersionString"] as? String ?? "0"
let UPDATE_URL = (info["LoggerUpdateURL"] as? String ?? "").trimmingCharacters(in: .whitespaces)
let BUILT_ON = info["LoggerBuiltOn"] as? String ?? ""
// chave pública de quem assina as atualizações (vem do repositório, mac/UPDATE_KEY)
let BUNDLE_KEY = (info["LoggerUpdateKey"] as? String ?? "").trimmingCharacters(in: .whitespaces)
let MAX_UPDATE_BYTES = 200 * 1024 * 1024
let SUPPORT = FileManager.default.homeDirectoryForCurrentUser
    .appendingPathComponent("Library/Application Support/Logger")
let LOG_FILE = FileManager.default.homeDirectoryForCurrentUser
    .appendingPathComponent("Library/Logs/Logger.log")
// a chave de assinatura mora no chip de segurança deste Mac (Secure Enclave): o arquivo abaixo
// só funciona neste Mac e só assina depois do Touch ID ou da senha.
let SIGN_KEY_FILE = SUPPORT.appendingPathComponent("assinatura.chave")
let LOCAL_PUB_FILE = SUPPORT.appendingPathComponent("assinatura.pub")

/// O texto exato que é assinado. Tem que bater com tools/updatesig.py.
func updateMessage(version: String, sha: String, size: Int) -> Data {
    Data("logger-update:v1\n\(version)\n\(sha.lowercased())\n\(size)".utf8)
}

/// Chaves aceitas: a que veio no app e a criada neste Mac. Vazio = ainda sem assinatura.
func trustedKeys() -> [P256.Signing.PublicKey] {
    var raw = [BUNDLE_KEY]
    if let l = try? String(contentsOf: LOCAL_PUB_FILE, encoding: .utf8) { raw.append(l) }
    return raw.compactMap { s in
        let t = s.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !t.isEmpty, !t.hasPrefix("__"), let d = Data(base64Encoded: t) else { return nil }
        return try? P256.Signing.PublicKey(x963Representation: d)
    }
}

// MARK: assinatura pelo certificado da Apple (Developer ID)
// time da conta Apple de quem publica; tools/release.py assina cada versão com esse certificado, sem Touch ID
let UPDATE_TEAM = "3S46YRW3J9"
// Apple Root CA (a raiz de todos os certificados Developer ID), impressão digital SHA-256
let APPLE_ROOT_CA_SHA256 = "b0b1730ecbc7ff4505142c49f1295e6eda6bcaed7e2c68c5be91b5a11001f024"

func certHas(_ c: SecCertificate, oid: String) -> Bool {
    let v = SecCertificateCopyValues(c, [oid] as CFArray, nil) as? [String: Any]
    return v?[oid] != nil
}

func subjectOUs(_ c: SecCertificate) -> [String] {
    let k = kSecOIDX509V1SubjectName as String
    guard let v = SecCertificateCopyValues(c, [k] as CFArray, nil) as? [String: Any],
          let s = v[k] as? [String: Any], let items = s[kSecPropertyKeyValue as String] as? [[String: Any]] else { return [] }
    return items.compactMap { ($0[kSecPropertyKeyLabel as String] as? String) == (kSecOIDOrganizationalUnitName as String) ? $0[kSecPropertyKeyValue as String] as? String : nil }
}

/// Assinatura feita pelo certificado Developer ID da Apple (CMS/PKCS#7, gerada por tools/release.py).
/// Aceita só se: a mensagem dentro é exatamente a esperada, a cadeia vai até a raiz da Apple
/// e o certificado é Developer ID Application do time UPDATE_TEAM.
func appleSignatureValid(_ b64: String, message: Data) -> Bool {
    guard let blob = Data(base64Encoded: b64) else { return false }
    var dec: CMSDecoder?
    guard CMSDecoderCreate(&dec) == errSecSuccess, let d = dec else { return false }
    let ok1 = blob.withUnsafeBytes { CMSDecoderUpdateMessage(d, $0.baseAddress!, blob.count) }
    guard ok1 == errSecSuccess, CMSDecoderFinalizeMessage(d) == errSecSuccess else { return false }
    var content: CFData?
    guard CMSDecoderCopyContent(d, &content) == errSecSuccess, let c = content as Data?, c == message else { return false }
    var n = 0
    guard CMSDecoderGetNumSigners(d, &n) == errSecSuccess, n == 1 else { return false }
    var status = CMSSignerStatus.unsigned, trust: SecTrust?, vr: OSStatus = 0
    guard CMSDecoderCopySignerStatus(d, 0, SecPolicyCreateBasicX509(), true, &status, &trust, &vr) == errSecSuccess,
          status == .valid, let t = trust else { return false }
    guard SecTrustEvaluateWithError(t, nil) else { return false }
    var chain: [SecCertificate] = []
    for i in 0..<SecTrustGetCertificateCount(t) { if let x = SecTrustGetCertificateAtIndex(t, i) { chain.append(x) } }
    // mesma regra que o macOS usa para "Developer ID": raiz da Apple, intermediário Developer ID, folha do time
    guard chain.count >= 3, let leaf = chain.first, let root = chain.last else { return false }
    let rootSHA = SHA256.hash(data: SecCertificateCopyData(root) as Data).map { String(format: "%02x", $0) }.joined()
    guard rootSHA == APPLE_ROOT_CA_SHA256 else { return false }
    guard certHas(chain[1], oid: "1.2.840.113635.100.6.2.6"), certHas(leaf, oid: "1.2.840.113635.100.6.1.13") else { return false }
    return subjectOUs(leaf).contains(UPDATE_TEAM)
}

/// nil = assinatura válida (ou app ainda sem chave); texto = motivo da recusa.
func signatureProblem(_ j: [String: Any], version: String, sha: String) -> String? {
    let keys = trustedKeys()
    if keys.isEmpty { return nil }
    guard let size = j["size"] as? Int, size > 0 else { return "a versão não informa o tamanho" }
    let msg0 = updateMessage(version: version, sha: sha, size: size)
    if let a = j["applesig"] as? String, appleSignatureValid(a, message: msg0) { return nil }
    guard let b64 = j["sig"] as? String, let d = Data(base64Encoded: b64),
          let sig = try? P256.Signing.ECDSASignature(derRepresentation: d) else { return "a versão não está assinada" }
    let msg = updateMessage(version: version, sha: sha, size: size)
    return keys.contains { $0.isValidSignature(sig, for: msg) } ? nil : "a assinatura não confere"
}

func sha256Hex(_ u: URL) -> String {
    (try? Data(contentsOf: u)).map { SHA256.hash(data: $0).map { String(format: "%02x", $0) }.joined() } ?? ""
}

func fileSize(_ u: URL) -> Int {
    ((try? FileManager.default.attributesOfItem(atPath: u.path))?[.size] as? NSNumber)?.intValue ?? -1
}

/// Só aceita endereços do repositório do Logger no GitHub.
func isRepoURL(_ s: String) -> Bool {
    guard let u = URL(string: s), u.scheme == "https", u.host == "raw.githubusercontent.com" else { return false }
    return u.path.hasPrefix("/juniorsousa6/Logger/")
}

final class TextBox { var text = ""; var found = false }

final class AppDelegate: NSObject, NSApplicationDelegate, WKNavigationDelegate, WKScriptMessageHandlerWithReply {
    var window: NSWindow!
    var web: WKWebView!
    var server: Process?
    var baseURL: URL?
    var quitting = false

    // MARK: ciclo de vida
    func applicationDidFinishLaunching(_ n: Notification) {
        buildMenu()
        let cfg = WKWebViewConfiguration()
        cfg.userContentController.addScriptMessageHandler(self, contentWorld: .page, name: "logger")
        web = WKWebView(frame: .zero, configuration: cfg)
        web.setValue(false, forKey: "drawsBackground")
        web.navigationDelegate = self

        window = NSWindow(contentRect: NSRect(x: 0, y: 0, width: 1100, height: 820),
                          styleMask: [.titled, .closable, .miniaturizable, .resizable],
                          backing: .buffered, defer: false)
        window.title = "Logger"
        window.titlebarAppearsTransparent = true
        window.titleVisibility = .hidden
        window.appearance = NSAppearance(named: .darkAqua)
        window.backgroundColor = NSColor(srgbRed: 0.027, green: 0.031, blue: 0.039, alpha: 1)
        window.minSize = NSSize(width: 720, height: 560)
        window.center()
        window.setFrameAutosaveName("LoggerMain")
        window.contentView = web
        window.makeKeyAndOrderFront(nil)
        NSApp.activate(ignoringOtherApps: true)

        guard toolsInstalled() else { askInstallTools(); return }
        startServer()
        if osChangedSinceBuild() { offerRebuild() }
        else { DispatchQueue.main.asyncAfter(deadline: .now() + 4) { self.checkUpdates(manual: false) } }
    }

    func applicationShouldTerminateAfterLastWindowClosed(_ s: NSApplication) -> Bool { true }

    func applicationShouldTerminate(_ s: NSApplication) -> NSApplication.TerminateReply {
        if !quitting && copyRunning() {
            let a = NSAlert()
            a.messageText = "Tem uma cópia em andamento"
            a.informativeText = "Se sair agora, a cópia para no meio. Nada é apagado do cartão, e da próxima vez o Logger copia só o que faltou."
            a.addButton(withTitle: "Continuar copiando")
            a.addButton(withTitle: "Sair mesmo assim")
            if a.runModal() == .alertFirstButtonReturn { return .terminateCancel }
        }
        quitting = true
        return .terminateNow
    }

    func applicationWillTerminate(_ n: Notification) {
        quitting = true
        server?.terminate()
    }

    // MARK: motor em Python
    func toolsInstalled() -> Bool {
        let p = Process()
        p.executableURL = URL(fileURLWithPath: "/usr/bin/xcode-select")
        p.arguments = ["-p"]
        p.standardOutput = FileHandle.nullDevice
        p.standardError = FileHandle.nullDevice
        do { try p.run(); p.waitUntilExit() } catch { return false }
        return p.terminationStatus == 0
    }

    func askInstallTools() {
        let a = NSAlert()
        a.messageText = "Falta um componente grátis da Apple"
        a.informativeText = "O Logger usa as Ferramentas de Linha de Comando da Apple. Clique em Instalar, espere terminar e abra o Logger de novo."
        a.addButton(withTitle: "Instalar")
        a.addButton(withTitle: "Sair")
        if a.runModal() == .alertFirstButtonReturn {
            let p = Process()
            p.executableURL = URL(fileURLWithPath: "/usr/bin/xcode-select")
            p.arguments = ["--install"]
            try? p.run()
        }
        NSApp.terminate(nil)
    }

    func startServer() {
        guard let res = Bundle.main.resourceURL?.appendingPathComponent("app") else { return }
        try? FileManager.default.createDirectory(at: LOG_FILE.deletingLastPathComponent(), withIntermediateDirectories: true)
        if !FileManager.default.fileExists(atPath: LOG_FILE.path) {
            FileManager.default.createFile(atPath: LOG_FILE.path, contents: nil)
        }
        let err = try? FileHandle(forWritingTo: LOG_FILE)
        err?.seekToEndOfFile()

        let p = Process()
        p.executableURL = URL(fileURLWithPath: "/usr/bin/python3")
        p.arguments = [res.appendingPathComponent("app.py").path]
        p.currentDirectoryURL = res
        var env = ProcessInfo.processInfo.environment
        env["LOGGER_PORT"] = "0"
        env["LOGGER_NO_BROWSER"] = "1"
        env["LOGGER_PARENT_PID"] = String(ProcessInfo.processInfo.processIdentifier)
        env["PYTHONDONTWRITEBYTECODE"] = "1"
        env["PYTHONUNBUFFERED"] = "1"
        p.environment = env
        let out = Pipe()
        p.standardOutput = out
        p.standardError = err ?? FileHandle.nullDevice
        let buffer = TextBox()
        out.fileHandleForReading.readabilityHandler = { [weak self] h in
            let d = h.availableData
            if d.isEmpty { h.readabilityHandler = nil; return }
            buffer.text += String(decoding: d, as: UTF8.self)
            guard !buffer.found, let r = buffer.text.range(of: "LOGGER_URL "),
                  buffer.text[r.upperBound...].contains("\n") else { return }
            buffer.found = true
            let line = buffer.text[r.upperBound...].prefix { $0 != "\n" }.trimmingCharacters(in: .whitespaces)
            guard let u = URL(string: line) else { return }
            DispatchQueue.main.async {
                self?.baseURL = u
                self?.web.load(URLRequest(url: u))
            }
        }
        p.terminationHandler = { [weak self] pr in
            DispatchQueue.main.async {
                guard let self = self, !self.quitting else { return }
                self.serverDied(pr.terminationStatus)
            }
        }
        do { try p.run(); server = p } catch { serverDied(-1) }
    }

    func serverDied(_ code: Int32) {
        let a = NSAlert()
        a.messageText = "O motor do Logger parou"
        a.informativeText = "Código \(code). O registro está em ~/Library/Logs/Logger.log. Pode reabrir; nada no cartão foi alterado."
        a.addButton(withTitle: "Reabrir")
        a.addButton(withTitle: "Mostrar registro")
        a.addButton(withTitle: "Sair")
        switch a.runModal() {
        case .alertFirstButtonReturn: baseURL = nil; startServer()
        case .alertSecondButtonReturn: NSWorkspace.shared.activateFileViewerSelecting([LOG_FILE]); NSApp.terminate(nil)
        default: NSApp.terminate(nil)
        }
    }

    func copyRunning() -> Bool {
        guard let b = baseURL, let u = URL(string: "api/progress", relativeTo: b),
              let d = try? Data(contentsOf: u),
              let j = try? JSONSerialization.jsonObject(with: d) as? [String: Any],
              let phase = j["phase"] as? String else { return false }
        return ["comecando", "copiando", "conferindo", "relatorio"].contains(phase)
    }

    // MARK: ponte com a interface (painel nativo de pastas)
    func userContentController(_ c: WKUserContentController, didReceive m: WKScriptMessage,
                               replyHandler: @escaping (Any?, String?) -> Void) {
        guard let body = m.body as? [String: Any], body["cmd"] as? String == "pick" else {
            replyHandler(nil, "comando desconhecido"); return
        }
        let panel = NSOpenPanel()
        panel.canChooseDirectories = true
        panel.canChooseFiles = false
        panel.canCreateDirectories = true
        panel.allowsMultipleSelection = false
        panel.message = body["prompt"] as? String ?? "Escolha a pasta"
        panel.prompt = "Escolher"
        panel.directoryURL = URL(fileURLWithPath: "/Volumes")
        panel.beginSheetModal(for: window) { r in
            replyHandler(r == .OK ? panel.url?.path : "", nil)
        }
    }

    // links externos abrem no navegador, não dentro do app
    func webView(_ w: WKWebView, decidePolicyFor a: WKNavigationAction,
                 decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        if let u = a.request.url, let host = u.host, host != "127.0.0.1", u.scheme?.hasPrefix("http") == true {
            NSWorkspace.shared.open(u); decisionHandler(.cancel); return
        }
        decisionHandler(.allow)
    }

    // MARK: atualizações
    func newer(_ a: String, than b: String) -> Bool {
        let x = a.split(separator: ".").map { Int($0) ?? 0 }, y = b.split(separator: ".").map { Int($0) ?? 0 }
        for i in 0..<max(x.count, y.count) {
            let p = i < x.count ? x[i] : 0, q = i < y.count ? y[i] : 0
            if p != q { return p > q }
        }
        return false
    }

    @objc func checkUpdatesMenu(_ s: Any?) { checkUpdates(manual: true) }

    func checkUpdates(manual: Bool) {
        guard !UPDATE_URL.isEmpty, let u = URL(string: UPDATE_URL) else {
            if manual { say("Atualização automática ainda não configurada", "Por enquanto, rode o instalador da versão nova. Suas configurações e o histórico ficam.") }
            return
        }
        var req = URLRequest(url: u)
        req.cachePolicy = .reloadIgnoringLocalCacheData
        URLSession.shared.dataTask(with: req) { d, _, _ in
            let j = d.flatMap { try? JSONSerialization.jsonObject(with: $0) as? [String: Any] }
            DispatchQueue.main.async {
                guard let j = j, let v = j["version"] as? String, let zip = j["url"] as? String,
                      let sha = j["sha256"] as? String, !sha.isEmpty else {
                    if manual { self.say("Não consegui verificar agora", "Confira a internet e tente de novo.") }
                    return
                }
                if self.newer(v, than: APP_VERSION) {
                    if let why = signatureProblem(j, version: v, sha: sha) {
                        self.log("atualização \(v) recusada: \(why)")
                        if manual { self.say("Não vou instalar a versão \(v)", "Por segurança: \(why). Nada foi baixado. Fale com quem publica o Logger.") }
                        return
                    }
                    let size = j["size"] as? Int ?? 0
                    if size > MAX_UPDATE_BYTES { return }
                    if !manual && self.copyRunning() { return }  // não interrompe cópia; avisa na próxima abertura
                    self.offerUpdate(v, zip: zip, sha: sha, size: size, notes: j["notes"] as? String ?? "")
                } else if manual {
                    self.say("Você já está na versão mais nova", "Logger \(APP_VERSION).")
                }
            }
        }.resume()
    }

    func offerUpdate(_ v: String, zip: String, sha: String, size: Int, notes: String) {
        let a = NSAlert()
        a.messageText = "Logger \(v) disponível"
        a.informativeText = (notes.isEmpty ? "" : notes + "\n\n") + "Você está na \(APP_VERSION). A atualização leva menos de um minuto e mantém suas pastas, cartões lembrados e histórico."
        a.addButton(withTitle: "Atualizar agora")
        a.addButton(withTitle: "Depois")
        guard a.runModal() == .alertFirstButtonReturn, let u = URL(string: zip) else { return }
        URLSession.shared.downloadTask(with: u) { tmp, _, err in
            guard let tmp = tmp, err == nil else {
                DispatchQueue.main.async { self.say("O download falhou", err?.localizedDescription ?? "") }
                return
            }
            let dir = FileManager.default.temporaryDirectory.appendingPathComponent("logger-update-\(v)")
            try? FileManager.default.removeItem(at: dir)
            try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
            let z = dir.appendingPathComponent("pacote.zip")
            try? FileManager.default.moveItem(at: tmp, to: z)
            // so instala se o pacote baixado for exatamente o publicado (tamanho + impressao digital SHA-256,
            // e os dois estao dentro da assinatura conferida antes de oferecer)
            let n = fileSize(z)
            guard n > 0, n <= MAX_UPDATE_BYTES, size == 0 || n == size, sha256Hex(z) == sha.lowercased() else {
                DispatchQueue.main.async { self.say("O pacote baixado não confere", "A atualização foi cancelada por segurança. Tente de novo mais tarde.") }
                return
            }
            let unzip = Process()
            unzip.executableURL = URL(fileURLWithPath: "/usr/bin/ditto")
            unzip.arguments = ["-x", "-k", z.path, dir.path]
            try? unzip.run(); unzip.waitUntilExit()
            let installer = dir.appendingPathComponent("Logger/Instalar Logger.command")
            DispatchQueue.main.async { self.runInstaller(installer) }
        }.resume()
    }

    // MARK: recompilar quando o macOS muda
    func osChangedSinceBuild() -> Bool {
        let now = ProcessInfo.processInfo.operatingSystemVersion.majorVersion
        guard let built = Int(BUILT_ON.split(separator: ".").first ?? "") else { return false }
        return built != now
    }

    func offerRebuild() {
        let installer = SUPPORT.appendingPathComponent("source/Instalar Logger.command")
        guard FileManager.default.fileExists(atPath: installer.path) else { return }
        let a = NSAlert()
        a.messageText = "O macOS foi atualizado"
        a.informativeText = "O Logger foi preparado para o macOS \(BUILT_ON). Quer refazer o app para esta versão do sistema? Leva menos de um minuto e mantém tudo."
        a.addButton(withTitle: "Atualizar o Logger")
        a.addButton(withTitle: "Agora não")
        if a.runModal() == .alertFirstButtonReturn { runInstaller(installer) }
    }

    func runInstaller(_ installer: URL) {
        if copyRunning() {  // nunca fecha o app no meio de uma copia
            say("Tem uma cópia em andamento", "Espere a cópia terminar e atualize depois (menu Logger › Procurar Atualizações…).")
            return
        }
        guard FileManager.default.fileExists(atPath: installer.path) else {
            say("Pacote de atualização incompleto", "Tente de novo mais tarde."); return
        }
        let p = Process()
        p.executableURL = URL(fileURLWithPath: "/bin/bash")
        p.arguments = [installer.path, "--update", "--wait-pid", String(ProcessInfo.processInfo.processIdentifier)]
        let log = try? FileHandle(forWritingTo: LOG_FILE)
        log?.seekToEndOfFile()
        p.standardOutput = log ?? FileHandle.nullDevice
        p.standardError = log ?? FileHandle.nullDevice
        do { try p.run() } catch { say("Não consegui atualizar", error.localizedDescription); return }
        quitting = true
        NSApp.terminate(nil)
    }

    // MARK: assinatura das versões (só no Mac de quem publica)
    func log(_ t: String) {
        guard let h = try? FileHandle(forWritingTo: LOG_FILE) else { return }
        h.seekToEndOfFile(); h.write(Data("[\(Date())] \(t)\n".utf8)); try? h.close()
    }

    func copyToClipboard(_ t: String) {
        NSPasteboard.general.clearContents(); NSPasteboard.general.setString(t, forType: .string)
    }

    func localPublicKey() -> String? {
        (try? String(contentsOf: LOCAL_PUB_FILE, encoding: .utf8))?.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    @objc func signingKeyMenu(_ s: Any?) {
        if let pub = localPublicKey(), FileManager.default.fileExists(atPath: SIGN_KEY_FILE.path) {
            copyToClipboard(pub)
            say("Este Mac já tem a chave de assinatura", "A parte pública foi copiada. Cole na conversa se pedirem:\n\n\(pub)")
            return
        }
        guard SecureEnclave.isAvailable else {
            say("Este Mac não tem chip de segurança", "Não dá para criar a chave aqui."); return
        }
        let a = NSAlert()
        a.messageText = "Criar a chave de assinatura neste Mac?"
        a.informativeText = "Ela fica presa no chip de segurança deste Mac e não sai dele. Cada versão nova do Logger só vale depois que você assinar aqui, com Touch ID ou senha.\n\nSe este Mac sumir, a chave vai junto: aí é só instalar o Logger de novo pelo instalador."
        a.addButton(withTitle: "Criar chave"); a.addButton(withTitle: "Cancelar")
        guard a.runModal() == .alertFirstButtonReturn else { return }
        do {
            var err: Unmanaged<CFError>?
            guard let ac = SecAccessControlCreateWithFlags(nil, kSecAttrAccessibleWhenUnlockedThisDeviceOnly,
                                                           [.privateKeyUsage, .userPresence], &err) else {
                throw err!.takeRetainedValue() as Error
            }
            let key = try SecureEnclave.P256.Signing.PrivateKey(accessControl: ac)
            try FileManager.default.createDirectory(at: SUPPORT, withIntermediateDirectories: true)
            try key.dataRepresentation.write(to: SIGN_KEY_FILE, options: .atomic)
            try? FileManager.default.setAttributes([.posixPermissions: 0o600], ofItemAtPath: SIGN_KEY_FILE.path)
            let pub = key.publicKey.x963Representation.base64EncodedString()
            try pub.write(to: LOCAL_PUB_FILE, atomically: true, encoding: .utf8)
            copyToClipboard(pub)
            log("chave de assinatura criada")
            say("Chave criada", "A parte pública (pode mostrar, não é segredo) foi copiada. Cole na conversa:\n\n\(pub)")
        } catch {
            say("Não consegui criar a chave", error.localizedDescription)
        }
    }

    @objc func signReleaseMenu(_ s: Any?) {
        guard let blob = try? Data(contentsOf: SIGN_KEY_FILE) else {
            say("Este Mac ainda não tem chave", "Primeiro use Logger › Chave de Assinatura…"); return
        }
        let a = NSAlert()
        a.messageText = "Assinar versão nova"
        a.informativeText = "Cole o link da versão que te mandaram na conversa."
        let field = NSTextField(frame: NSRect(x: 0, y: 0, width: 420, height: 24))
        let clip = NSPasteboard.general.string(forType: .string)?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        field.stringValue = isRepoURL(clip) ? clip : ""
        field.placeholderString = "https://raw.githubusercontent.com/juniorsousa6/Logger/…/latest.json"
        a.accessoryView = field
        a.addButton(withTitle: "Conferir"); a.addButton(withTitle: "Cancelar")
        a.window.initialFirstResponder = field
        guard a.runModal() == .alertFirstButtonReturn else { return }
        let link = field.stringValue.trimmingCharacters(in: .whitespacesAndNewlines)
        guard isRepoURL(link), let u = URL(string: link) else {
            say("Link não aceito", "Só assino versões do repositório do Logger no GitHub."); return
        }
        var req = URLRequest(url: u); req.cachePolicy = .reloadIgnoringLocalCacheData
        URLSession.shared.dataTask(with: req) { d, _, _ in
            let parsed = d.flatMap { try? JSONSerialization.jsonObject(with: $0) as? [String: Any] }
            guard let j = parsed, let v = j["version"] as? String, let zip = j["url"] as? String, isRepoURL(zip),
                  let sha = j["sha256"] as? String, let size = j["size"] as? Int, size > 0, size <= MAX_UPDATE_BYTES,
                  let zu = URL(string: zip) else {
                DispatchQueue.main.async { self.say("Esse link não é de uma versão", "Confira o link e tente de novo.") }
                return
            }
            // baixa o pacote e confere com os próprios olhos do Mac: o que for assinado é o que você baixou
            URLSession.shared.downloadTask(with: zu) { tmp, _, err in
                guard let tmp = tmp, err == nil else {
                    DispatchQueue.main.async { self.say("O download falhou", err?.localizedDescription ?? "") }
                    return
                }
                let n = fileSize(tmp), got = sha256Hex(tmp)
                DispatchQueue.main.async {
                    guard n == size, got == sha.lowercased() else {
                        self.say("O pacote não confere com a versão", "Não assinei nada. Avise na conversa."); return
                    }
                    let c = NSAlert()
                    c.messageText = "Assinar o Logger \(v)?"
                    let mb = String(format: "%.1f MB", Double(size) / 1_048_576)
                    let notes = j["notes"] as? String ?? ""
                    c.informativeText = (notes.isEmpty ? "" : notes + "\n\n") +
                        "Pacote conferido: \(mb), impressão digital \(got.prefix(8))…\(got.suffix(8)).\n\nSó assine se foi você que pediu esta versão."
                    c.addButton(withTitle: "Assinar"); c.addButton(withTitle: "Cancelar")
                    guard c.runModal() == .alertFirstButtonReturn else { return }
                    self.signNow(blob: blob, version: v, sha: got, size: size)
                }
            }.resume()
        }.resume()
    }

    func signNow(blob: Data, version: String, sha: String, size: Int) {
        let ctx = LAContext()
        ctx.localizedReason = "assinar o Logger \(version)"
        DispatchQueue.global(qos: .userInitiated).async {
            do {
                let key = try SecureEnclave.P256.Signing.PrivateKey(dataRepresentation: blob, authenticationContext: ctx)
                let msg = updateMessage(version: version, sha: sha, size: size)
                let sig = try key.signature(for: msg)
                guard key.publicKey.isValidSignature(sig, for: msg) else { throw CocoaError(.featureUnsupported) }
                let b64 = sig.derRepresentation.base64EncodedString()
                DispatchQueue.main.async {
                    self.copyToClipboard(b64)
                    self.log("versão \(version) assinada")
                    self.say("Logger \(version) assinado", "A assinatura foi copiada. Cole na conversa:\n\n\(b64)")
                }
            } catch {
                DispatchQueue.main.async { self.say("Não assinei", error.localizedDescription) }
            }
        }
    }

    // MARK: menus e avisos
    func say(_ t: String, _ m: String) {
        let a = NSAlert(); a.messageText = t; a.informativeText = m; a.runModal()
    }

    @objc func reload(_ s: Any?) { if let b = baseURL { web.load(URLRequest(url: b)) } }
    @objc func showLog(_ s: Any?) { NSWorkspace.shared.activateFileViewerSelecting([LOG_FILE]) }

    func buildMenu() {
        let main = NSMenu()
        func sub(_ title: String, _ items: [NSMenuItem]) {
            let it = NSMenuItem(); let m = NSMenu(title: title)
            items.forEach { m.addItem($0) }
            it.submenu = m; main.addItem(it)
        }
        func item(_ t: String, _ a: Selector?, _ k: String = "", target: AnyObject? = nil, mods: NSEvent.ModifierFlags = [.command]) -> NSMenuItem {
            let i = NSMenuItem(title: t, action: a, keyEquivalent: k)
            i.keyEquivalentModifierMask = mods
            i.target = target
            return i
        }
        sub("Logger", [
            item("Sobre o Logger", #selector(NSApplication.orderFrontStandardAboutPanel(_:))),
            item("Procurar Atualizações…", #selector(checkUpdatesMenu(_:)), target: self),
            .separator(),
            item("Chave de Assinatura…", #selector(signingKeyMenu(_:)), target: self),
            item("Assinar Versão Nova…", #selector(signReleaseMenu(_:)), target: self),
            .separator(),
            item("Ocultar Logger", #selector(NSApplication.hide(_:)), "h"),
            item("Ocultar Outros", #selector(NSApplication.hideOtherApplications(_:)), "h", mods: [.command, .option]),
            .separator(),
            item("Sair do Logger", #selector(NSApplication.terminate(_:)), "q"),
        ])
        sub("Editar", [
            item("Desfazer", Selector(("undo:")), "z"),
            item("Refazer", Selector(("redo:")), "z", mods: [.command, .shift]),
            .separator(),
            item("Recortar", #selector(NSText.cut(_:)), "x"),
            item("Copiar", #selector(NSText.copy(_:)), "c"),
            item("Colar", #selector(NSText.paste(_:)), "v"),
            item("Selecionar Tudo", #selector(NSText.selectAll(_:)), "a"),
        ])
        sub("Janela", [
            item("Minimizar", #selector(NSWindow.performMiniaturize(_:)), "m"),
            item("Recarregar", #selector(reload(_:)), "r", target: self),
            .separator(),
            item("Mostrar Registro", #selector(showLog(_:)), target: self),
        ])
        NSApp.mainMenu = main
    }
}

let app = NSApplication.shared
let delegate = AppDelegate()
app.delegate = delegate
app.setActivationPolicy(.regular)
app.run()
